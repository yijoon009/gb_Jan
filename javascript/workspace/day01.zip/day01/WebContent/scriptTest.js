/**
 * 이미지 마우스 이벤트
 */

function over(obj){
	obj.src = "icon2.png";
}

function out(obj){
	obj.src = "icon1.png";
}